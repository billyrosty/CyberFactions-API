package fr.billyrosty.factions.api.event.faction;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.HandlerList;

public class FactionUpgradeEvent extends CyberFactionsEvent {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FactionSnapshot faction;
    private final int newLevel;

    public FactionUpgradeEvent(FactionSnapshot faction, int newLevel) {
        this.faction = faction;
        this.newLevel = newLevel;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    public int getNewLevel() {
        return newLevel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
