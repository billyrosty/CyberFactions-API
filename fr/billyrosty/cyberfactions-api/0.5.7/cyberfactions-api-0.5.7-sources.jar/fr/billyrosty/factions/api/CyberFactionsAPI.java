package fr.billyrosty.factions.api;

import fr.billyrosty.factions.api.addon.AddonRegistry;
import fr.billyrosty.factions.api.command.CommandRegistry;
import fr.billyrosty.factions.api.permission.PermissionRegistry;
import fr.billyrosty.factions.api.service.*;
import fr.billyrosty.factions.api.upgrade.UpgradeRegistry;
import org.bukkit.plugin.Plugin;

public interface CyberFactionsAPI {

    FactionService getFactionService();

    PlayerService getPlayerService();

    ClaimService getClaimService();

    EconomyService getEconomyService();

    RelationService getRelationService();

    TeleportationService getTeleportationService();

    RoleService getRoleService();

    CommandRegistry getCommandRegistry();

    PermissionRegistry getPermissionRegistry();

    UpgradeRegistry getUpgradeRegistry();

    AddonRegistry getAddonRegistry();

    Plugin getPlugin();

    static CyberFactionsAPI getInstance() {
        return CyberFactionsAPIProvider.get();
    }
}
