package fr.billyrosty.factions.api.event;

import org.bukkit.event.Event;

public abstract class CyberFactionsEvent extends Event {

    protected CyberFactionsEvent() {
        super();
    }

    protected CyberFactionsEvent(boolean async) {
        super(async);
    }
}
