package fr.billyrosty.factions.api.event.player;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.HandlerList;

public class FPlayerWithdrawEvent extends CyberFactionsEvent {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot player;
    private final FactionSnapshot faction;
    private final double amount;

    public FPlayerWithdrawEvent(FPlayerSnapshot player, FactionSnapshot faction, double amount) {
        this.player = player;
        this.faction = faction;
        this.amount = amount;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FPlayerSnapshot getPlayer() {
        return player;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
