package fr.billyrosty.factions.api.event.player;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.HandlerList;

public class FPlayerTerritoryEnterEvent extends CyberFactionsEvent {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot player;
    private final FactionSnapshot from;
    private final FactionSnapshot to;

    public FPlayerTerritoryEnterEvent(FPlayerSnapshot player, FactionSnapshot from, FactionSnapshot to) {
        this.player = player;
        this.from = from;
        this.to = to;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FPlayerSnapshot getPlayer() {
        return player;
    }

    public FactionSnapshot getFrom() {
        return from;
    }

    public FactionSnapshot getTo() {
        return to;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
