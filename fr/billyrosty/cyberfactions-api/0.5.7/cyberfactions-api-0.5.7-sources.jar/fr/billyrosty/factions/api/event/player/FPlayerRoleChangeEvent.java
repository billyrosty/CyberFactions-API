package fr.billyrosty.factions.api.event.player;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;

public class FPlayerRoleChangeEvent extends CyberFactionsEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot player;
    private final String oldRole;
    private final String newRole;
    private boolean cancelled = false;

    public FPlayerRoleChangeEvent(FPlayerSnapshot player, String oldRole, String newRole) {
        this.player = player;
        this.oldRole = oldRole;
        this.newRole = newRole;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FPlayerSnapshot getPlayer() {
        return player;
    }

    public String getOldRole() {
        return oldRole;
    }

    public String getNewRole() {
        return newRole;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
