package fr.billyrosty.factions.api.service;

import fr.billyrosty.factions.api.model.RoleSnapshot;

import java.util.Collection;
import java.util.Optional;

public interface RoleService {

    Collection<RoleSnapshot> getRegisteredRoles();

    Optional<RoleSnapshot> getRole(String id);

    Optional<RoleSnapshot> getRoleByPlayer(java.util.UUID player);

    String getServerName();
}
