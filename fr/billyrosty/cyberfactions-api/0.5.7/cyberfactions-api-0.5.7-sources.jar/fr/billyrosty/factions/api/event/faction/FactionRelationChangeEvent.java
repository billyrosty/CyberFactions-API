package fr.billyrosty.factions.api.event.faction;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;

public class FactionRelationChangeEvent extends CyberFactionsEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FactionSnapshot faction;
    private final FactionSnapshot targetFaction;
    private final String relationId;
    private boolean cancelled = false;

    public FactionRelationChangeEvent(FactionSnapshot faction, FactionSnapshot targetFaction, String relationId) {
        this.faction = faction;
        this.targetFaction = targetFaction;
        this.relationId = relationId;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    public FactionSnapshot getTargetFaction() {
        return targetFaction;
    }

    public String getRelationId() {
        return relationId;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
