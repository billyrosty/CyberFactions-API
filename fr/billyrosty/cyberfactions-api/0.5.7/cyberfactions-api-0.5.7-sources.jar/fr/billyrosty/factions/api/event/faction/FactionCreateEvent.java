package fr.billyrosty.factions.api.event.faction;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;

public class FactionCreateEvent extends CyberFactionsEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot creator;
    private final FactionSnapshot faction;
    private boolean cancelled = false;

    public FactionCreateEvent(FPlayerSnapshot creator, FactionSnapshot faction) {
        this.creator = creator;
        this.faction = faction;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FPlayerSnapshot getCreator() {
        return creator;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
