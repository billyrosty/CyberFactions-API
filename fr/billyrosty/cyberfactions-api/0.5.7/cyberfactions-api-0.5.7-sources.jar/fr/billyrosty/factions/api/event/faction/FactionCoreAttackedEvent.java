package fr.billyrosty.factions.api.event.faction;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.CoreSnapshot;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.HandlerList;

public class FactionCoreAttackedEvent extends CyberFactionsEvent {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FactionSnapshot faction;
    private final CoreSnapshot core;

    public FactionCoreAttackedEvent(FactionSnapshot faction, CoreSnapshot core) {
        this.faction = faction;
        this.core = core;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    public CoreSnapshot getCore() {
        return core;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
