package fr.billyrosty.factions.api.event.faction;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;

public class FactionDescriptionChangeEvent extends CyberFactionsEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot player;
    private final FactionSnapshot faction;
    private final String newDescription;
    private boolean cancelled = false;

    public FactionDescriptionChangeEvent(FPlayerSnapshot player, FactionSnapshot faction, String newDescription) {
        this.player = player;
        this.faction = faction;
        this.newDescription = newDescription;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FPlayerSnapshot getPlayer() {
        return player;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    public String getNewDescription() {
        return newDescription;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
