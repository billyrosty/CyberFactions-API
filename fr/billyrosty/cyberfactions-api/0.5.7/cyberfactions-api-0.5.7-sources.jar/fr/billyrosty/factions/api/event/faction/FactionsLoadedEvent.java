package fr.billyrosty.factions.api.event.faction;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import org.bukkit.event.HandlerList;

public class FactionsLoadedEvent extends CyberFactionsEvent {

    private static final HandlerList HANDLERS = new HandlerList();
    private final int factionCount;

    public FactionsLoadedEvent(int factionCount) {
        this.factionCount = factionCount;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public int getFactionCount() {
        return factionCount;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
