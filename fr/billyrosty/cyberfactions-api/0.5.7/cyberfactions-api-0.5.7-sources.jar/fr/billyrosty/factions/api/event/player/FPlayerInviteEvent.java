package fr.billyrosty.factions.api.event.player;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;

public class FPlayerInviteEvent extends CyberFactionsEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot inviter;
    private final String invitedName;
    private final FactionSnapshot faction;
    private boolean cancelled = false;

    public FPlayerInviteEvent(FPlayerSnapshot inviter, String invitedName, FactionSnapshot faction) {
        this.inviter = inviter;
        this.invitedName = invitedName;
        this.faction = faction;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FPlayerSnapshot getInviter() {
        return inviter;
    }

    public String getInvitedName() {
        return invitedName;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
