package fr.billyrosty.factions.api.event.player;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;

public class FPlayerKickedEvent extends CyberFactionsEvent implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot kicker;
    private final FPlayerSnapshot kicked;
    private final FactionSnapshot faction;
    private boolean cancelled = false;

    public FPlayerKickedEvent(FPlayerSnapshot kicker, FPlayerSnapshot kicked, FactionSnapshot faction) {
        this.kicker = kicker;
        this.kicked = kicked;
        this.faction = faction;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FPlayerSnapshot getKicker() {
        return kicker;
    }

    public FPlayerSnapshot getKicked() {
        return kicked;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
