package fr.billyrosty.factions.api.event.player;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import org.bukkit.event.HandlerList;

public class FPlayerChatModeChangeEvent extends CyberFactionsEvent {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot player;
    private final String oldMode;
    private final String newMode;

    public FPlayerChatModeChangeEvent(FPlayerSnapshot player, String oldMode, String newMode) {
        this.player = player;
        this.oldMode = oldMode;
        this.newMode = newMode;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FPlayerSnapshot getPlayer() {
        return player;
    }

    public String getOldMode() {
        return oldMode;
    }

    public String getNewMode() {
        return newMode;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
