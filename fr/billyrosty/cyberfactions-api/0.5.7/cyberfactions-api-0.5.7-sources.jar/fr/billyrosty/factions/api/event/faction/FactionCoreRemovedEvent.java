package fr.billyrosty.factions.api.event.faction;

import fr.billyrosty.factions.api.event.CyberFactionsEvent;
import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.HandlerList;

public class FactionCoreRemovedEvent extends CyberFactionsEvent {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FactionSnapshot faction;

    public FactionCoreRemovedEvent(FactionSnapshot faction) {
        this.faction = faction;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }
}
