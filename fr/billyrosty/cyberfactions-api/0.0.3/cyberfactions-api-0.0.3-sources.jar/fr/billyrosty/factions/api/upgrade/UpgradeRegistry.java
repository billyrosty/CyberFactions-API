package fr.billyrosty.factions.api.upgrade;

import java.util.Collection;
import java.util.Optional;

public interface UpgradeRegistry {

    void registerProperty(CustomProperty property);

    void unregisterProperty(String key);

    Optional<CustomProperty> getProperty(String key);

    Collection<CustomProperty> getRegisteredProperties();

    Object getPropertyValue(int factionId, String propertyKey);

    <T> T getPropertyValue(int factionId, String propertyKey, Class<T> type);

    int getFactionLevel(int factionId);
}
