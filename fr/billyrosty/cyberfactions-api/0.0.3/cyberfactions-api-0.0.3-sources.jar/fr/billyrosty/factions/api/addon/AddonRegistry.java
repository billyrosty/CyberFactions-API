package fr.billyrosty.factions.api.addon;

import java.util.Collection;
import java.util.Optional;

public interface AddonRegistry {

    void registerAddon(CyberAddon addon);

    void unregisterAddon(String id);

    Optional<CyberAddon> getAddon(String id);

    Collection<CyberAddon> getRegisteredAddons();

    boolean isAddonEnabled(String id);
}
