package fr.billyrosty.factions.api.permission;

public enum PermissionType {
    ROLE,
    RELATION,
    BOTH
}
