package fr.billyrosty.factions.api.model;

import java.util.List;

public interface RelationSnapshot {

    String getId();

    String getSingular();

    String getPlural();

    List<String> getAliases();

    String getColor();

    boolean isPvpAllowed();

    boolean needsRequest();

    int getRequestTimeout();

    List<String> getDeniedCommands();
}
