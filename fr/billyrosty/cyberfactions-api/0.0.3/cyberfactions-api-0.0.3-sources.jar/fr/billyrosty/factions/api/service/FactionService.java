package fr.billyrosty.factions.api.service;

import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import fr.billyrosty.factions.api.model.FactionSnapshot;

import java.util.Collection;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;

public interface FactionService {

    Optional<FactionSnapshot> getFaction(int id);

    Optional<FactionSnapshot> getFaction(String name);

    Optional<FactionSnapshot> getFactionByPlayer(UUID player);

    Collection<FactionSnapshot> getAllFactions();

    boolean isFactionNameTaken(String name);

    FactionSnapshot createFaction(String name, UUID owner);

    void disbandFaction(int factionId);

    void join(UUID player, int factionId);

    void leave(UUID player);

    void kick(UUID kicker, UUID target);

    void invite(int factionId, UUID target, String inviterName);

    void changeRole(UUID target, String roleId);

    void setOwner(int factionId, UUID newOwner);

    void setName(int factionId, String name);

    void setDescription(int factionId, String description);

    void setLevel(int factionId, int level);

    void setAdmin(int factionId, boolean admin);

    void mutateFaction(int factionId, Consumer<MutableFaction> mutator);

    interface MutableFaction {

        void setName(String name);

        void setDescription(String description);

        void setLevel(int level);

        void setBank(double bank);

        void setAdmin(boolean admin);

        void setOwner(UUID owner);
    }
}
