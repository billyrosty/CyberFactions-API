package fr.billyrosty.factions.api.service;

import fr.billyrosty.factions.api.model.RelationSnapshot;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface RelationService {

    Collection<RelationSnapshot> getRegisteredRelations();

    Optional<RelationSnapshot> getRelation(String id);

    String getRelationBetween(int factionId1, int factionId2);

    boolean areAllied(int factionId1, int factionId2);

    boolean areEnemies(int factionId1, int factionId2);

    boolean areNeutral(int factionId1, int factionId2);

    void setRelation(int factionId1, int factionId2, String relationId);

    void clearRelation(int factionId1, int factionId2);

    List<Integer> getFactionsWithRelation(int factionId, String relationId);

    boolean isPvpAllowed(int factionId1, int factionId2);
}
