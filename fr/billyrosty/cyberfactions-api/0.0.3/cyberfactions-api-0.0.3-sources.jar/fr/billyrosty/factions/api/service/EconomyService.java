package fr.billyrosty.factions.api.service;

public interface EconomyService {

    double getBalance(int factionId);

    void setBalance(int factionId, double amount);

    void deposit(int factionId, double amount);

    void withdraw(int factionId, double amount);

    double getBankLimit(int factionId);

    boolean hasEnough(int factionId, double amount);
}
