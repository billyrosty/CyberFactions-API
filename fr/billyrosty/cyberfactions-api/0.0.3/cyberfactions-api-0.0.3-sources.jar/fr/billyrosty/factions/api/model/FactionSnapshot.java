package fr.billyrosty.factions.api.model;

import org.bukkit.Material;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface FactionSnapshot {

    int getId();

    String getName();

    String getDescription();

    UUID getOwner();

    int getLevel();

    List<UUID> getMembers();

    int getMembersCount();

    int getPower();

    int getMaxPower();

    double getBank();

    Date getCreationDate();

    boolean isWilderness();

    boolean isSafeZone();

    boolean isWarZone();

    boolean isAdmin();

    boolean isSystemFaction();

    FLocationSnapshot getHome();

    CoreSnapshot getCore();

    Map<Material, Long> getBlocksCount();

    Map<Integer, String> getRelations();

    Object getLevelProperty(String property);

    List<FPlayerSnapshot> getOnlineMembers();

    List<FPlayerSnapshot> getOfflineMembers();

    String getRelation(int factionId);

    boolean isNeutral(int factionId);

    boolean hasPermission(FPlayerSnapshot player, String permission);
}
