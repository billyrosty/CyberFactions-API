package fr.billyrosty.factions.api.service;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public interface TeleportationService {

    void teleportToHome(Player player);

    void teleportToHome(Player player, boolean bypassWarmup);

    void teleport(Player player, Location location, boolean bypassWarmup);

    void teleport(Player player, String server, Location location, boolean bypassWarmup);

    boolean hasPendingTeleportation(Player player);

    void cancelPendingTeleportation(Player player);

    int getWarmupDuration();
}
