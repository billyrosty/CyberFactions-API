package fr.billyrosty.factions.api.model;

import org.bukkit.Location;

public interface FLocationSnapshot {

    double getX();

    double getY();

    double getZ();

    float getYaw();

    float getPitch();

    String getWorld();

    String getServer();

    Location toBukkitLocation();
}
