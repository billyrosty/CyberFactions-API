package fr.billyrosty.factions.api.event;

import fr.billyrosty.factions.api.model.FPlayerSnapshot;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class FPlayerEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FPlayerSnapshot player;
    private final Type type;

    public enum Type {
        JOINED_FACTION,
        LEFT_FACTION,
        KICKED,
        ROLE_CHANGED,
        POWER_CHANGED,
        CHAT_MODE_CHANGED,
        ENTERED_FACTION_TERRITORY,
        TELEPORTED
    }

    public FPlayerEvent(FPlayerSnapshot player, Type type) {
        this.player = player;
        this.type = type;
    }

    public FPlayerSnapshot getPlayer() {
        return player;
    }

    public Type getType() {
        return type;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
