package fr.billyrosty.factions.api.model;

public interface ClaimSnapshot {

    String getServer();

    String getWorld();

    int getX();

    int getZ();

    int getFactionId();
}
