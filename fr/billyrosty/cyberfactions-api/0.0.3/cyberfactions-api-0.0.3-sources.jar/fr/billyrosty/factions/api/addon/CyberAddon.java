package fr.billyrosty.factions.api.addon;

import fr.billyrosty.factions.api.CyberFactionsAPI;
import org.bukkit.plugin.Plugin;

public interface CyberAddon {

    String getId();

    String getName();

    String getVersion();

    String getAuthor();

    Plugin getOwningPlugin();

    default String getAddonDescription() {
        return "";
    }

    void onEnable(CyberFactionsAPI api);

    void onDisable();

    default void onReload() {}
}
