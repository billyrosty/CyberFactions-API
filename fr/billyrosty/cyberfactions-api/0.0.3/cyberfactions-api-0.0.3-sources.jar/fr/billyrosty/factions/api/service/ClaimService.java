package fr.billyrosty.factions.api.service;

import fr.billyrosty.factions.api.model.ClaimSnapshot;
import org.bukkit.Chunk;
import org.bukkit.Location;

import java.util.Collection;
import java.util.Optional;

public interface ClaimService {

    boolean isClaimed(String server, String world, int x, int z);

    boolean isClaimed(Chunk chunk);

    boolean isClaimed(Location location);

    Optional<ClaimSnapshot> getClaimAt(String server, String world, int x, int z);

    Optional<ClaimSnapshot> getClaimAt(Location location);

    int getFactionIdAt(String server, String world, int x, int z);

    int getFactionIdAt(Location location);

    Collection<ClaimSnapshot> getClaims(int factionId);

    int getClaimCount(int factionId);

    void claim(int factionId, String server, String world, int x, int z);

    void claim(int factionId, Chunk chunk);

    void unclaim(String server, String world, int x, int z);

    void unclaim(Chunk chunk);

    void unclaimAll(int factionId);

    boolean isInOwnTerritory(java.util.UUID player);
}
