package fr.billyrosty.factions.api.model;

import java.util.UUID;

public interface CoreSnapshot {

    FLocationSnapshot getLocation();

    String getSkin();

    UUID getEntityId();

    int getHealth();

    boolean isPlaced();

    long getLastAttack();

    long getLastDeath();
}
