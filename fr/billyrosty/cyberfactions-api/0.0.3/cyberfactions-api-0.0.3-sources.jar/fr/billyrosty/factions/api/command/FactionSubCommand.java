package fr.billyrosty.factions.api.command;

import org.bukkit.command.CommandSender;

import java.util.Collections;
import java.util.List;

public interface FactionSubCommand {

    String getName();

    String getDescription();

    default String getLongDescription() {
        return getDescription();
    }

    String getSyntax();

    default boolean canConsole() {
        return false;
    }

    default String getPermission() {
        return null;
    }

    void execute(CommandSender sender, String[] args);

    default List<String> tabComplete(CommandSender sender, String[] args) {
        return Collections.emptyList();
    }
}
