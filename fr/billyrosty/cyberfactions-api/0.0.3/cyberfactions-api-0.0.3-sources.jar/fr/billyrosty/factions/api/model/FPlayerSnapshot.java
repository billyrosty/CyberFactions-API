package fr.billyrosty.factions.api.model;

import java.util.UUID;

public interface FPlayerSnapshot {

    UUID getUuid();

    String getName();

    int getFactionId();

    boolean hasFaction();

    String getRole();

    double getPower();

    boolean hasMaxPower();

    boolean hasMinPower();

    String getChatMode();

    boolean isSpyMode();

    long getFlyTime();

    boolean isFlying();

    long getLastConnect();

    long getLastDisconnect();

    boolean isOnline();

    FLocationSnapshot getLastLocation();
}
