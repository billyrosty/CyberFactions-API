package fr.billyrosty.factions.api;

public final class CyberFactionsAPIProvider {

    private static CyberFactionsAPI instance;

    private CyberFactionsAPIProvider() {}

    public static CyberFactionsAPI get() {
        if (instance == null) {
            throw new IllegalStateException("CyberFactions API is not loaded yet.");
        }
        return instance;
    }

    public static void register(CyberFactionsAPI api) {
        if (instance != null) {
            throw new IllegalStateException("CyberFactions API is already registered.");
        }
        instance = api;
    }

    public static void unregister() {
        instance = null;
    }
}
