package fr.billyrosty.factions.api.upgrade;

public interface CustomProperty {

    String getKey();

    Object getDefaultValue();

    PropertyType getType();

    enum PropertyType {
        INTEGER,
        DOUBLE,
        FLOAT,
        BOOLEAN,
        STRING,
        STRING_LIST,
        MAP
    }
}
