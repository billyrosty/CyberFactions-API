package fr.billyrosty.factions.api.service;

import fr.billyrosty.factions.api.model.FPlayerSnapshot;

import java.util.Collection;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;

public interface PlayerService {

    Optional<FPlayerSnapshot> getPlayer(UUID uuid);

    Optional<FPlayerSnapshot> getPlayer(String name);

    Collection<FPlayerSnapshot> getAllPlayers();

    boolean hasAccount(UUID uuid);

    boolean hasFaction(UUID uuid);

    boolean isBypassing(UUID uuid);

    void setBypassing(UUID uuid, boolean bypass);

    boolean isAutoClaiming(UUID uuid);

    void setAutoClaiming(UUID uuid, boolean autoClaim);

    void addPower(UUID uuid, double amount);

    void removePower(UUID uuid, double amount);

    void setFlyTime(UUID uuid, long seconds);

    void setChatMode(UUID uuid, String chatMode);

    void setSpyMode(UUID uuid, boolean spy);

    void mutatePlayer(UUID uuid, Consumer<MutablePlayer> mutator);

    interface MutablePlayer {

        void setPower(double power);

        void setRole(String roleId);

        void setChatMode(String chatMode);

        void setSpyMode(boolean spy);

        void setFlyTime(long seconds);
    }
}
