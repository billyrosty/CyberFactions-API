package fr.billyrosty.factions.api.model;

public interface RoleSnapshot {

    String getId();

    String getName();

    String getPrefix();

    String getSuffix();

    int getPower();

    boolean hasPermission(String permission);
}
