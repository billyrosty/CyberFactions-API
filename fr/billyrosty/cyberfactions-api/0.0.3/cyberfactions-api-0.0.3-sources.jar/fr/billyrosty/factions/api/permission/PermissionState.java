package fr.billyrosty.factions.api.permission;

public enum PermissionState {
    ALLOWED,
    DENIED,
    UNDEFINED
}
