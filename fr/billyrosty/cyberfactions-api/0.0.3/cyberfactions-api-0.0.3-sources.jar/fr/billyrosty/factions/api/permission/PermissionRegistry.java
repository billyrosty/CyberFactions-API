package fr.billyrosty.factions.api.permission;

import java.util.Collection;
import java.util.Optional;

public interface PermissionRegistry {

    void registerPermission(CustomPermission permission);

    void unregisterPermission(String id);

    Optional<CustomPermission> getPermission(String id);

    Collection<CustomPermission> getRegisteredPermissions();

    boolean hasPermission(int factionId, java.util.UUID player, String permissionId);

    void setPermission(int factionId, String roleOrRelationId, String permissionId, PermissionState state);

    PermissionState getPermissionState(int factionId, String roleOrRelationId, String permissionId);
}
