package fr.billyrosty.factions.api.event;

import fr.billyrosty.factions.api.model.FactionSnapshot;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class FactionEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();
    private final FactionSnapshot faction;
    private final Type type;

    public enum Type {
        CREATED,
        DISBANDED,
        CLAIMED,
        UNCLAIMED,
        UNCLAIMED_ALL,
        UPGRADED,
        RENAMED,
        DESCRIPTION_CHANGED,
        HOME_SET,
        HOME_REMOVED,
        CORE_SET,
        CORE_REMOVED,
        CORE_ATTACKED,
        CORE_DESTROYED,
        PERMISSION_CHANGED,
        RELATION_CHANGED
    }

    public FactionEvent(FactionSnapshot faction, Type type) {
        this.faction = faction;
        this.type = type;
    }

    public FactionSnapshot getFaction() {
        return faction;
    }

    public Type getType() {
        return type;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
