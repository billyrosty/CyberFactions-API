package fr.billyrosty.factions.api.permission;

public interface CustomPermission {

    String getId();

    String getDisplayName();

    String getDescription();

    PermissionState getDefaultState();

    PermissionType getType();
}
