package fr.billyrosty.factions.api.command;

import java.util.Collection;

public interface CommandRegistry {

    void registerSubCommand(FactionSubCommand command);

    void unregisterSubCommand(String name);

    boolean hasSubCommand(String name);

    Collection<FactionSubCommand> getRegisteredCommands();

    void registerTabCompleter(String commandName, int argIndex, TabCompleter completer);

    void unregisterTabCompleter(String commandName, int argIndex);
}
